package sinn;

public class Planet {
double durchmesser;
double dichte;
double masse;
double fallbeschleunigung;
double rotationsperiode;

//Atmosph�re
double druck;
double temperaturMin;
double temperaturAvg;
double temperaturMax;
double stickstoff;
double sauerstoff;
double argon;
double co2;
double neon;
}
