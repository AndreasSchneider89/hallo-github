package sinn;

import java.util.List;

public class Existenz {
String name;
int level;
String Typ;
double energie;
//Wunsch wunsch;

List<Existenz> erschaffen;
}
