package sinn;

public class Atom {
String name;
int ordnungszahl;
int protonen;
int neutronen;
int elektronenzahl;
Elektron[] elektronen;
double atomgewicht;
double dichte;
double elektronegativit�t;
int Periode;
String Gruppe;
String Serie;
double Schmelztemperatur;
double Sidetemperatur;

public Atom(int ordnungszahl) {
	protonen = ordnungszahl;
	// name und neutronenzahl aus Exeltabelle
	elektronenzahl = ordnungszahl;
	elektronen = new Elektron[elektronenzahl];
}

public void elBestimmen(Elektron[] elektonen) {
	
}

}
