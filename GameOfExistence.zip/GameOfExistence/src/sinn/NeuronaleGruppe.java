package sinn;

public class NeuronaleGruppe {
double wert = 0;// bsp.: 1) Wert der Geistigen st�rke berechnen z.b: Mitteln bzw Bausteinforrmatierung
//2) -> Wert = Summe aller Bausteine*AvgVerbindungseffizienzEffiziens... Sp�ter anpassen der Gleichung
//3) Schrittweise Verbesserung: Angleichen an k�nstliche neuronale Netze sowie Simmulation zu aktuellen 
// realen Mathematischen Abh�gigkeiten bzw. Zusammenh�ngen vor allem auf neuronal-biologischer Ebene
// Programmieren, Testen z.B: (Wahrscheinlichkeitsprognose == Real),  und Verallgemeinern weiterer Simmulationsf�higkeiten
}
