package sinn;

// Die Bewusstseinsstruktur Weltenbaum grenzt sich vor allem dadurch von anderen Lebewesen ab, 
//dass sich die Wahrnehmung auf das Verstehen, Beeinflussen und Kontrollieren anderer (denkender)Lebewesen fokussiert.
//imitiere neuronale Strukturen,  Effiziens basierend auf gro�er quantit�t sowie einer geeigneten Verbindung relevaner
//Strukturen - > Erzeugen von kollektivem Bewusstsein, Transformationsversuche des Bewusstseins in richtung der eigenen Form:
//Intuitiv, Geistige Verbundenheit bzw. dauerhafte Anpassung zum halten der geistigen Gleichheit. jeglicher handlung, bis hin
//zum K�rperlichen Verwachsen: Komatisieren, Mumifizieren, Weitere Annglichungen auf allen Ebenen. Basierend auf intuitiver, 
//jedoch extrem h�ufiger Kombination von Instinkt, Emotion, Neuronalen Indikatoren zur einsch�tzung von Erfolg und 
//Misserfolgswahrscheinlichkeit auf Basis von  direkter momentaner geistiger Verbindung oder Erinnerungen im Kollektiven Bewusstsein.
//Parameter des Bewusstseins:
	//Wille; Wahrnehmung, Entscheidungsfindung; Ged�chnis f�r Optimierung,...
	//Au�ere Zw�nge, Nebenmotive, Anpassungsgr�nde, H�rte von Umwelt, Habitabilit�t des Planeteb
	//
	// 1) Typen: 
	
	//Weltenbaum; 

public class Weltenbaum extends Lebewesen{

	
}
