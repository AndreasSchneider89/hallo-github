package sinn;

public class Lebewesen {

}
