package sinn;

public class Elektron {
int hauptquantenzahl;
int nebenquantenzahl;
int megnetquantenzahl;
double spinquantenzahl;
}
