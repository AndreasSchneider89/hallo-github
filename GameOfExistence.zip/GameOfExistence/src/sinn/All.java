package sinn;

public class All {

	public void effiziens{
		
	}
}
