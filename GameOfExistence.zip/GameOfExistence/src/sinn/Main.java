package sinn;

import acm.program.GraphicsProgram;

public class Main extends GraphicsProgram{

}
