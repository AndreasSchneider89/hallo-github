package sinn;

public class Wahrnehmung {

}
