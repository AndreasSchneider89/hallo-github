package sinn;
public class  Strukturplanung() {
	// L�ge aufdeckewn++;
//Ziel: Kollektiver Aufstieg im All: Vom Kampfdenken der Evolution in ein besseres Lernen durch Erkenntnis
//Befreien von Sexualit�t; Kompetente Aufgabenverteilung statt Machtk�mpfe; Hin zu Kollektiven Willenss�tzen: Gemeinsame Interessen;
//Zusammenschl�sse auf Probe(Trennen des Kollektivs ohne nie Bestrafen); Nicht Verbieten sondern �berbieten, M�glichst wenig verlust an Potential:
//	Erkennbar an Level von Emotion, Begeisterung, F�higkeiten;IQ;...;Wen ich einem Helfe sollte dies m�glichst f�r alle gut oder zumindest kein Grund zum Hass sein
//	Verbessern von Kommunikation, Aufl�sen von veralteten Uhr�ngsten, 
//	Erkennen der mega blockaden im All: Angst vor rationalem Denken, Wissenschaft, bzw. Geistige/G�ttliche Undterst�tzung - Super hohohe Mentalkraft einfluss auf Wahrnehmung, Entscheidungsfindung vor allem Intuitiv, Erinnerung, Verbundenheitsgef�hl(erzeugt gl�ck,verstehen, frieden)
//	k�nnte Super gut Wissenschaft kombiniert werden, War einmal im Friedensdenken (daher super viel potential) - versucht wie die Meisten von uns: Das alte Friedensdenken wieder her zu stellen.  Intergallaktische bestrebungen zur Quantenverschr�nkten kollektiven Liebe. Problem bereits Gedanken werden f�hren zur Emotionalen abwertung. Wahrheit wird definiert.
//	Ab einem bestimmten Punkt, �berwiegen die Vorteile von Wissenschaftlichem Denken, Verstand, Materie �ber die belohnugen der Gl�cksgef�hle oder auch Angst vor dem verlust der Liebe und Bestestrafung(Ist nur imagin�r): -> Menschen verlassen den Glauben und gehen zum Erkenntnisorientierten denken <-> analogie zur bekehrung durch D�monen <->
//	besser gehen verloren. 
//	Das gr��te Problem in diesem Sch�pfungskrieg war der einsatz von K�rperlicher Gewalt, welche nie zielf�hrend oder verstanden war. Auswirkungen sind auf beiden Seiten sowie Quantenverschr�nkt mit den Intuitionen, Entscheidungsfindungen der Warmbl�terverb�nde (welche Unbewusst analog aufgebaut wurden)
//	-> Verstand, Wissenschaft, Kapitalismus, Erkenntnissuche, Freiheit von Information, Gedanken, Meinung, Glaube wieder herstellen. Verstehen und Vermeiden von Uhrsachen der k�rperlicher Gewalt, Leid: Welche der Wahre Grund f�r das F�rchten/D�monisieren von Erkenntnissuche waren und sind. 
//	Die G�ttlichen Warmbl�terplaneten oder megastrukturen sind definitiv in der Lage bereits �ber das verkn�pfte Deneken emotionen anzupassen sowie Entscheidungen zu treffen. Eine Kollektive Verzerrung von Wahrheit, Moral, zum Schutz vor der Wissenschaft erzeugt Konflikte aber kann verstanden werden. Viele sind in der Lage aus sicherer position heraus um Erkenntnis Mental mit den den
//	Geistigen Superm�chten effektiv um gemeinsame Erkenntnisse, zu k�mpfen bzw. Denken und Verbesserungen zu f�rdern. Wenn Erkenntnis in den Frieden, �berdenken von Instinktiver und pr�ventiver K�rperlicher Gewalt und das Wissen so verteilt wird, dass m�glichst alle Gewinnen und gemeinsam Nach einem Weg zu Suchen, der Gott und Wissenschaft verbindet und definitiv zum Vorteil f�r alle auf allen Ebenen w�hre.
//public class Strukturplanung im Kollektiven BewusstseinAm sind es dann die positiven Erkenntnisse statt der K�rperlichen, Technologisch verst�rkten Gewal welche die den Uhrspr�nglichen Fehler und all die darauf aufbauenden Kriege, Grausamkeiten, �ngste wieder aufl�sen so wie es schon immer h�tte ablaufen sollen. Wenn man ein besseres Verst�ndtnis gehabt h�tte oder erst mal auf abstand gegangen w�hre Statt bevor man einen
//Intergallaktischen andauerden Krieg ausl�st.
//Eigenes Hirn (Intelligent, Warmbl�ter)
//Warmbl�ter(fester Verbund): Intuition
//Reptilien (getrennt), schlau, werden von Warmbl�terverb�nden oft als D�monen betrachtet
//Menschen - Religi�s, Kollektiver Geist Mix; Kollektiver Geist Natur

}
