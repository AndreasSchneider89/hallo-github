package sinn;

public class Neuron {
double Zustand[];
double 


// Bewusstes ver�ndern, der emotionalen Bewertung von Wahrnehmungen

public aufwerten () {
	
}

	}


