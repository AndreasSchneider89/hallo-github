package sinn;

public class Wunsch {

}
